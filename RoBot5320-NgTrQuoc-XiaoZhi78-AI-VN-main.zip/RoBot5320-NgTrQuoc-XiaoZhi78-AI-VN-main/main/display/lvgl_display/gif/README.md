# 说明 / Description

## 中文

本目录代码移植自 LVGL 的 GIF 程序。

主要修复和改进：
- 修复了透明背景问题
- 兼容了 87a 版本的 GIF 格式

## English

The code in this directory is ported from LVGL's GIF program.

Main fixes and improvements:
- Fixed transparent background issues
- Added compatibility for GIF 87a version format
